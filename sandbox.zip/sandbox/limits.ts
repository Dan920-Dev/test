export const dockerLimits = {
  cpus: '1',
  memory: '512m',
  pidsLimit: 128,
  tmpfsSize: '16m'
};