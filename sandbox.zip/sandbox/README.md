## Comandos

npm install -g ts-node typescript

ts-node test.ts

npm init -y

npm install --save-dev typescript @types/node

npm install ts-node     

npm install typescript

npx tsc

npx ts-node test.ts