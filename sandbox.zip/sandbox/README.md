## Comandos

npm install -g ts-node typescript

ts-node test.ts
