import { writeFileSync, mkdirSync } from 'fs';
import { join } from 'path';

export function prepareWorkdir(sessionId: string, sourceCode: string): string {
  const basePath = '/host/tmp/ariadna';
  const workdir = join(basePath, sessionId);
  mkdirSync(workdir, { recursive: true });
  writeFileSync(join(workdir, 'Main.cpp'), sourceCode);
  return workdir;
}