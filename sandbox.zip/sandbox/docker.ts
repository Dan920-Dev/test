import { spawnSync } from 'child_process';
import { dockerLimits } from './limits';

export function runDockerCompiler(workdir: string, flags: string[], sessionId: string) {
  const compileCmd = ['g++', ...flags, '-static-pie', '-s', '-o', 'main', 'Main.cpp'];
  const fallbackCmd = ['g++', ...flags, '-s', '-o', 'main', 'Main.cpp'];

  const dockerArgs = [
    'run', '--rm',
    '--network', 'none',
    '--cpus=1', '--memory=512m', '--pids-limit=128',
    '--read-only', '-v', `${workdir}:/work:rw`,
    '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges',
    '-u', '10000:10000',
    '--tmpfs', '/tmp:rw,nosuid,nodev,noexec,size=16m',
    '-w', '/work',
    'gcc:13-bookworm'
  ];

  const result = spawnSync('docker', [...dockerArgs, ...compileCmd], { timeout: 30000 });

  if (result.error && result.error.code === 'ETIMEDOUT') {
    return { ok: false, kind: 'TIMEOUT', stderr: '', exitCode: null };
  }

  if (result.error && result.error.message.includes('ENOMEM')) {
    return { ok: false, kind: 'OOM', stderr: '', exitCode: null };
  }

  if (result.status !== 0) {
    const fallback = spawnSync('docker', [...dockerArgs, ...fallbackCmd], { timeout: 30000 });
    if (fallback.status !== 0) {
      return {
        ok: false,
        kind: 'CE',
        stderr: fallback.stderr.toString().slice(0, 8192),
        exitCode: fallback.status
      };
    }
  }

  return {
    ok: true,
    binaryPath: `${workdir}/main`
  };
}